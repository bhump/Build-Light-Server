const accessToken = "wu63wfmqjhrnsl3lic4p6c6tg3f5cgwsmxi4cbrw6y5vl6rersvq";
const url = "https://dev.azure.com/lonelysasquatch/roasted/_apis/build/builds?$top=1&api-version=5.1";
var express = require('express');
const axios = require('axios').default;
var router = express.Router();
var bodyParser = require('body-parser');
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({
  extended: true
}));
var buildStatus = '';
var buildResult = '';

var isStausCheckEnabled = true;

/* GET home page. */
router.get('/', function (req, res, next) {
  getBuilds();

  res.render('index', {
    title: 'Lonely Sasquatch Status Hub',
    project: 'Status Hub',
    status: buildStatus
  });
});

router.post('/post', function (req, res) {
  let isEnabled = req.body.isEnabled;
  isStausCheckEnabled = isEnabled;

  res.render('index');
});

async function getBuilds() {

  setInterval(function () {

    if (isStausCheckEnabled) {

      var auth = 'Basic ' + Buffer.from("username" + ":" + accessToken).toString('base64');

      axios.get(url, {
          headers: {
            'Authorization': auth
          }

        }).then(function (response) {

          console.log(response.data);
          console.log(response.data.count);
          console.log(response.data.value[0].status);
          console.log(response.data.value[0].result);
          buildStatus = response.data.value[0].status;
          buildResult = response.data.value[0].result;

        }).catch(function (error) {
          // handle error
          console.log(error);
        })
        .finally(function () {});
    }
  }, 20000);
};

module.exports = router;